/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

/**
 *
 * @author zohoorsaadat
 */

/*KEY:

   A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
   K R Y P T O S A B C D E F G H I J L M N Q U V W X Z
*/

public class Substitution {
    
    public int[] keyStr;
    
    public Substitution()
    {
        
       
        
                         //k , r , y , ...
        keyStr=new int[] {107,114,121,112,116,
                          111,115,97,98,99,
                          100,101,102,103,104,
                          105,106,108,109,110,
                          113,117,118,119,120,
                          121,122};
        
        
                               
    }
    
    
}
