/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

import java.io.*;

/**
 *
 * @author zohoorsaadat
 */
public class Encryption {
    
    
public void enc() throws Exception {
    
    //Define Plain Text ant Cypher Text files
    int char1=0;
    int index;
    
    
    LetterFrequency myLetFreq=new LetterFrequency();
    Substitution mySub=new Substitution(); 
    try
    {  
        
        FileReader fr = new FileReader("plainText.txt");
        File file = new File("CyberText.txt");
        FileWriter fw = new FileWriter(file);
    
        while ((char1=fr.read()) != -1)
        {
            if(char1>=AsciCode.capitalLetterLB && char1<=AsciCode.capitalLetterUB)
            {
                index=char1-AsciCode.capitalLetterLB;  
                char1=mySub.keyStr[index];
            }
            else 
            if(char1>=AsciCode.letterLB && char1<=AsciCode.letterUB)  
            {
                index=char1-AsciCode.letterLB;
                char1=mySub.keyStr[index];
            }
            fw.write(char1); 
            //System.out.print((char) char1);
         
        }
        fr.close();
        fw.close();
    }
    catch (Exception ex)
    {
       throw ex;
    }
  
}
}
