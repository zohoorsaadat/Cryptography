/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

import java.io.*;


/**
 *
 * @author zohoorsaadat
 */
public class Decryption {
    
    
    
    public void dec(int [] keyy, int [] ss) throws Exception
    {
        int char1=0;
        int index=0;
        
        
        LetterFrequency myLetFreq = new LetterFrequency();
        try
        {  
            
            
            FileReader fr = new FileReader("CyberText.txt");
            

            while ((char1=fr.read()) != -1)
            {
                myLetFreq.addFreq(char1); 
            }
            fr.close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
       
        System.out.print("Number of characters:");
        System.out.println(myLetFreq.charNo);
        myLetFreq.calcOneLetFreq();
       
        
        myLetFreq.sortLetterFreq();
        myLetFreq.findInitKey();
      
            
        try
        { 
        
            FileReader fr = new FileReader("CyberText.txt");
            File file = new File("PlainTextt.txt");
             FileWriter fw = new FileWriter(file);
   
            while ((char1=fr.read()) != -1)
            {
                
                if(char1>=AsciCode.letterLB && char1<=AsciCode.letterUB)  
                {
                    index=char1-AsciCode.letterLB;
                    char1=myLetFreq.initKey[index];

                }
                fw.write(char1); 
               
                //passing initial key
                for(int i=0;i<keyy.length;i++)
                   keyy[i]=myLetFreq.initKey[i];
                //keyy=Array.copyOf(myLetFreq.initKey,myLetFreq.initKey.lenght
                
                //passing l2:letter frequency in cypher text
                for(int i =0; i<ss.length;i++)
                    ss[i]=(int) myLetFreq.l2[i][0];
                
            }
            fr.close();
            fw.close(); 
        }
        catch (Exception ex)
        {
            throw ex;
        }
    
        
       
    }

    
 }

