/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

import java.io.*;
import java.util.Arrays;

/**
 *
 * @author zohoorsaadat
 */
public class ImproveDecryption {
    
    public double[][] E,D1,D2;
    public int[] k1,k2;
    public int[] s;
    
    
    public  ImproveDecryption()
    {
        
        AsciCode myAsciCode= new AsciCode();
        int n= myAsciCode.alphabetSize;
        //means E
        E=new double[n][n];
        //means D
        D1= new double[n][n];
        //means D'
        D2= new double[n][n];
        //means k
        k1=new int[n];
        //means k'
        k2=new int[n];
        s=new int[n];
        
       
    }
    
    //exchange key
 /*   private int adjKey()
    {
        AsciCode myAsciCode= new AsciCode();
        
        
        int temp;
        
        int c=a;
        int d=b;
        alpha= s[c];
        beta= s[c+d];
        
        //swap alpha and beta in k'
        temp=k2[alpha-myAsciCode.letterLB];        
        k2[alpha-myAsciCode.letterLB]=k2[beta-myAsciCode.letterLB];
        k2[beta-myAsciCode.letterLB]=temp;
        
        a=a+1;
        //change D'
        if(a+b<=myAsciCode.alphabetSize)
            return 1;
        a=1;
        b=b+1;
        
        //terminate algorithm
        if(b==myAsciCode.alphabetSize)
            return -1;
        
        return 0;
        
    }*/
    
    //calculate v 
    private double calcV(int x)
    {
        double sigma=0;
        if(x==1)
        {
           for(int i=0; i<D1.length; i++)
               for(int j=0;j<D1.length;j++)
               {
                   double a=D1[i][j];
                   double b=E[i][j];
                   double c=Math.abs(D1[i][j]-E[i][j]);
                   
                   sigma+=Math.abs(D1[i][j]-E[i][j]);
                   
               }
        }
        else
        if(x==2)
        {
            for(int i=0; i<D2.length; i++)
               for(int j=0;j<D2.length;j++)
                   sigma+=Math.abs(D2[i][j]-E[i][j]);        
        }
        
        return sigma;
    }
    /////////////////////////////////////////////////
    private void printD(double[][] D)
    {
       System.out.print("==================================\n\n"); 
        double temp=0;
        for(int i=0;i<D.length;i++)
        {
           for(int j=0;j<D.length;j++)
           {
               temp=D[i][j];
               System.out.printf("%.3f",temp);
               System.out.print(" ");
               
           }
            System.out.print("\n");
        }
    System.out.print("==================================\n\n");
    }
    
    //exchange rows in D'
    private void exchangeRows(int alpha1,int beta1)
    {
        
        double temp;
        
        for(int j=0;j<D2.length;j++)
        {
           temp=D2[alpha1-AsciCode.letterLB][j];
           D2[alpha1-AsciCode.letterLB][j]=D2[beta1-AsciCode.letterLB][j];
           D2[beta1-AsciCode.letterLB][j]=temp;
        }
     printD(D2);   
        
    }
    
    //exchange columns in D'
    private void exchangeColumns(int alpha1,int beta1)
    {
        
        double temp;
        
        for(int i=0;i<D2.length;i++)
        {
           temp=D2[i][alpha1-AsciCode.letterLB];
           D2[i][alpha1-AsciCode.letterLB]=D2[i][beta1-AsciCode.letterLB];
           D2[i][beta1-AsciCode.letterLB]=temp;
        }
    printD(D2);    
    }
    
    public void impDec() throws Exception
    {
        int temp;
        
        int a=1,b=1;
        int alpha=0,beta=0;
        int counter=0;
        String str1="PlainTextt.txt";
        String str2="new.txt";
        
        int char1=0, char2=0;
        double v1=0,v2=0;
        
        int flag=0,flag1=0,flag2=0;
        
        Decryption myDecrypt=new Decryption();
        TwoLetterFrequency myTwoLetFreq = new TwoLetterFrequency();
        
        
        try
        {  
            myDecrypt.dec(k1,s);
            
            /*System.out.println();
            System.out.println();
            
            
            for(int i=0;i<k1.length;i++)
            {
                System.out.print((char)k1[i]);
                System.out.print(" ");
            }
            System.out.println();
            for(int i=0;i<s.length;i++)
            {
                System.out.print((char)s[i]);
                System.out.print(" ");
            }*/
        
            //initiate E
            myTwoLetFreq.initE();
            
            //initiate D
            
            FileReader fr = new FileReader(str1);
                       
            if((char1=fr.read())!=-1)
            {
                while ((char2=fr.read()) != -1)
                {
                    myTwoLetFreq.addTwoFreq(char1,char2);  
                    char1=char2;
                }
                 
            }
            myTwoLetFreq.calcTwoLetFreq();
            fr.close();
        }
        catch (Exception ex)
        {
            throw ex;
        }
            
            E=Arrays.copyOf(myTwoLetFreq.E, myTwoLetFreq.E.length);           
            D1=Arrays.copyOf(myTwoLetFreq.D, myTwoLetFreq.D.length);
            
            v1=calcV(1);
            
            //System.out.print(v1);
            
          
            while(flag==0&&counter<2000)   
            {
                //step 4 step 5
                if(flag2==0)
                {
                  k2=Arrays.copyOf(k1, k1.length);
                  D2=Arrays.copyOf(D1, D1.length);   
                }
                //step 6

                //step 6a
                alpha= s[a-1];
                beta= s[a+b-1];

                //swap alpha and beta in k'
                temp=k2[alpha-AsciCode.letterLB-1];        
                k2[alpha-AsciCode.letterLB-1]=k2[beta-AsciCode.letterLB-1];
                k2[beta-AsciCode.letterLB-1]=temp;

                //step 6b
                a=a+1;
                //step 6c 
                if(a+b<=AsciCode.alphabetSize)        
                    flag1=1;  //goto step7

                if(flag1==0)
                {
                    //step 6d
                    a=1;
                    //step 6e
                    b=b+1;

                    //if(b==26)
                        //System.in.read();
                    
                    //step 6f
                    if(b==AsciCode.alphabetSize)
                    {
                        flag=1;
                        
                    }

                }

                //step 7 flag1==1
                if(flag1==1&&flag==0)
                {
                    printD(D2);
                    System.out.print("\n"+alpha + " ----- "+ beta+ "\n");
                    exchangeRows(alpha,beta);
                    exchangeColumns(alpha,beta);
//------------------------------------------------------------------------------                    
                    
//                    try
//                    {
//                        
//                        FileReader fr = new FileReader(str1);
//                        File file = new File(str2);
//                        FileWriter fw = new FileWriter(file);
//                        
//                        while ((char1=fr.read()) != -1)
//                        {
//                          
//                            if(char1==alpha) 
//                              fw.write(beta);
//                          else                             
//                          if(char1==beta)
//                              fw.write(alpha);
//                          else
//                              fw.write(char1);
//                          
//                              
//                    }
//                    fr.close();
//                    fw.close();
//                    }
//                    
//                    catch (Exception ex)
//                    {
//                        throw ex;
//                    }
//                    try
//                    {
//                    //initiate D2
//            
//                        FileReader fr = new FileReader(str2);
//                       
//                        if((char1=fr.read())!=-1)
//                        {
//                            while ((char2=fr.read()) != -1)
//                            {
//                                myTwoLetFreq.addTwoFreq(char1,char2);  
//                                char1=char2;
//                            }
//                 
//                        }
//                        myTwoLetFreq.calcTwoLetFreq();
//                        fr.close();
//                    }
//                    catch (Exception ex)
//                    {
//                        throw ex;
//                    }
//                    
                    
//                    D2=Arrays.copyOf(myTwoLetFreq.D, myTwoLetFreq.D.length);
//------------------------------------------------------------------------------                    
                    //step 8
                    v2=calcV(2);

                    //step 9
                    if(v2>=v1)
                    {
                        flag2=1;
                        a=1;
                        b=1;
                        counter++;

                    }

                    //step 10, step 11, step 12
                    if(flag2==0)
                    {
                        v1=v2;
                        k1=Arrays.copyOf(k2, k2.length);
                        D1=Arrays.copyOf(D2, D2.length);
                    }   


                }
            }
                
                System.out.print("\n\n");
                System.out.print("Last key:\n");
                for(int i=0;i<k1.length;i++)
                {
                    System.out.print((char)k1[i]);
                    System.out.print(" ");
                }
        
    }
    
    
        
        
    
}
