/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

import java.io.*;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author zohoorsaadat
 */
public class TwoLetterFrequency {
    
    
    int n=AsciCode.alphabetSize;
    int charNo=0;
    //Original English Letter Frequcny    
    public double [][] E;
    
    //Cypher Text Letter Frequcny
    public double[][] D;
    
    public TwoLetterFrequency() throws Exception
    {
       
        
        D=new double[n][n];
        E=new double[n][n];
                            
      for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                E[i][j]=0.0;
        for(int i=0; i<n; i++)
            for(int j=0; j<n; j++)
                D[i][j]=0.0;
        
    }
    
    private int charArrayToInt(char []data,int start,int end) throws NumberFormatException
{
    int result = 0;
    for (int i = start; i < end; i++)
    {
        int digit = (int)data[i] - (int)'0';
        if ((digit < 0) || (digit > 9)) throw new NumberFormatException();
        result *= 10;
        result += digit;
    }
    return result;
}
   public void initE() throws Exception
{
       int index1=0, index2=0;
       String theString="";
       
       double num=0; 
    try
        {
            
          
            File file = new File("TwoLetterFreq.txt");
            Scanner scanner = new Scanner(file);
 
            
            while (scanner.hasNextLine()) 
            {
                theString = scanner.nextLine();
                char[] charArray = theString.toCharArray();
                num=charArrayToInt(charArray,3,charArray.length);               
                num/=45000000;
                index1= charArray[0];
                index2=charArray[1];
                E[index1-AsciCode.capitalLetterLB][index2-AsciCode.capitalLetterLB]=num;
                
                
            }
            scanner.close(); 
            /*char1='h';
            char2='e';
           System.out.print(E[char1-AsciCode.letterLB][char2-AsciCode.letterLB]);*/ 
           /* for (int x=0; x<E.length; x++) 
            {
               for (int y = 0; y<E.length; y++) 
               {
                   
                   System.out.print(E[x][y]);
                   System.in.read();   
               }
               
            }*/   
            /*File file1 = new File("value.txt");
            FileWriter fw = new FileWriter(file1);
            
           for (int x=0; x<E.length; x++) {
               for (int y = 0; y<E.length; y++) {
                   fw.write((int) E[x][y]);
               }
               fw.write("\n");
           }
            fw.close();*/
        }
        catch (Exception ex)
        {
            throw ex;
        }


}
    public void addTwoFreq(int c1, int c2)
    {
        int i=0,j=0;
        
        
        if((c1<=AsciCode.letterUB && c1>=AsciCode.letterLB)&&(c2<=AsciCode.letterUB && c2>=AsciCode.letterLB))
        {
            i=c1-AsciCode.letterLB;
            j=c2-AsciCode.letterLB;
            D[i][j]++;
            charNo++;
        }
    
    }
    public void calcTwoLetFreq()
    {
        for(int i=0; i<D.length;i++)
            for(int j=0;j<D.length;j++)       
               D[i][j]/=charNo;
    }
    
}
