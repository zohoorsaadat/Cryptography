/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package Crypto;

/**
 *
 * @author zohoorsaadat
 */


        
public class LetterFrequency 
{
    
    public int charNo;
     
    
    //Original English Letter Frequcny    
    private double [][] l1;
    
    //Cypher Text Letter Frequcny
    public double[][] l2;
    
    //Guessed Key
    public int[] initKey;
    
    public LetterFrequency()
    {
        charNo=0;
        
        
         
        //Original English Letter Frequency
        //Initialize l1
        
        l1=new double[][] {{97,8.2},{98,1.5},{99,2.8},{100,4.3},{101,12.7},
                           {102,2.2},{103,2.0},{104,6.1},{105,7.0},{106,0.2},
                           {107,0.8},{108,4.0},{109,2.4},{110,6.7},{111,7.5},
                           {112,1.9},{113,0.1},{114,6.0},{115,6.3},{116,9.1},
                           {117,2.8},{118,1.0},{119,2.4},{120,0.2},{121,2.0},
                           {122,0.1}};
 
        
        //Cypher Text Letter Frequency
        l2=new double[AsciCode.alphabetSize][2];  
        initKey=new int[AsciCode.alphabetSize];
      
        //Initialize l2
        for(int i=0; i<l2.length; i++)         
           l2[i][1]=0.0;  
      
        for(int i=0; i<l2.length; i++)
           l2[i][0]=AsciCode.letterLB+i;
      
        for(int i=0; i<initKey.length; i++)
            
                initKey[i]=0;
      
    }
    
    //Calculating Letter Frequency from Cypher Text
    
    public void addFreq( int c)
    {
        
        int i=0; 
        
        if(c<=AsciCode.capitalLetterUB && c>=AsciCode.capitalLetterLB)
        {
            i=c-AsciCode.capitalLetterLB;
            l2[i][1]+=1;
            charNo++;
        }
        
        if(c<=AsciCode.letterUB && c>=AsciCode.letterLB)
        {
            i=c-AsciCode.letterLB;
            l2[i][1]+=1;
            charNo++;
        }
        
       
    }
    
    //Normilazing the guessed key
    
    public void calcOneLetFreq()
    {
        for(int i=0; i<l2.length;i++)
            l2[i][1]/=charNo;
    }
    
    //Sorting English Letter Frequency
    
    public void sortLetterFreq()
    {
        for(int j=0;j<l1.length;j++)
            for(int i=0;i<l1.length-j-1;i++)
            {
                if(l1[i][1]<l1[i+1][1])
                {
                    double temp=l1[i][1];
                    l1[i][1]=l1[i+1][1];
                    l1[i+1][1]=temp;
                    
                    temp=l1[i][0];
                    l1[i][0]=l1[i+1][0];
                    l1[i+1][0]=temp;
                    
                }
            }
        
        // Sorting Cypher Text Letter Frequency
        
        for(int j=0;j<l2.length;j++)
            for(int i=0;i<l2.length-j-1;i++)
            {
                if(l2[i][1]<l2[i+1][1])
                {
                    double temp=l2[i][1];
                    l2[i][1]=l2[i+1][1];
                    l2[i+1][1]=temp;
                    
                    temp=l2[i][0];
                    l2[i][0]=l2[i+1][0];
                    l2[i+1][0]=temp;
                    
                }
                
            }
        
        
        System.out.print("decrising English letter Frequency:\n ");
        for(int i=0;i<l1.length;i++)
        {
            System.out.print((char) l1[i][0]);
            System.out.print(" ");
            //System.out.println(l1[i][1]);

        }
        System.out.println("\n");
        
        // print the sorted Cypher Text Letter Frequency
        System.out.print("decrising Cyber letter Frequency:\n ");
        for(int i=0;i<l2.length;i++)
        {
            System.out.print((char) l2[i][0]);
            System.out.print(" ");
            //System.out.println(l2[i][1]);

        }     
    }
    
    public void findInitKey()
    {
        int index=0;
        
        for(int i=0; i<l1.length; i++)
        {
            index=(int)l1[i][0]-AsciCode.letterLB;
            initKey[index]=(int) l2[i][0];
        }
        
        System.out.println("\n");
        System.out.print("English letters:\n ");
        for(int i=AsciCode.letterLB;i<AsciCode.letterUB;i++)
        {
            System.out.print((char)i);
            System.out.print(" ");
        }
        System.out.print("\n\n");
        System.out.print("Guessed key:\n ");
        for(int i=0; i<initKey.length; i++)
        {
            System.out.print((char) initKey[i]);
            System.out.print(" ");
        }   
        
    }
}
