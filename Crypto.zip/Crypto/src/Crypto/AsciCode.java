/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Crypto;

/**
 *
 * @author zohoorsaadat
 */
public final class AsciCode {
    
    public static final int alphabetSize=26; //change to 27
    public static final int capitalLetterLB=65;
    public static final int capitalLetterUB=90;
    public static final int letterLB=97;
    public static final int letterUB=122;
    
}
